package com.practice_01;
/**	
 * 
 * @author ������
 * @version 1.0
 *
 */
public class HellowWorld {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hellow World!");
	}

}
